# Kahoot-Smasher
This repository includes the source code of the app "SmashIt-Kahoot edition" which has since been removed from the Google Play store.
<br>
For all interested, here is the complete source code and assets.
<br>
Please understand that I have not spent time cleaning my code or adding meaningful comments so please be respectful.
<br>
## Contributions
If you would like to modify my code or re-distribute my work please credit me in your adaptation and link to this page.
<br>
This project can be edited and compiled using Android Studio.
<br>
(I would also appreciate it if you contacted me before republishing this project at dev.programsofdaveduck@gmail.com)
<br>
## Download
To download the pre-complied version (updated for android 7.0 + w/ZeevoX improvements), click [here](https://www.mediafire.com/file/z957oji4cmo506p/app-release.apk)
<br>
## License
I am not responsible for any misuse of this code, as I provide it as an educational resource only.
